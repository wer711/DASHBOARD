#!/bin/bash
# سكربت بناء Vercel
# يقوم بـ:
# 1. تبديل مزوّد Prisma من SQLite إلى PostgreSQL (لأن Vercel لا يدعم SQLite)
# 2. توليد عميل Prisma
# 3. دفع المخطط إلى قاعدة البيانات
# 4. بناء Next.js
set -e

echo "=== Vercel Build Script ==="
echo "Provider before:"
grep "provider" prisma/schema.prisma | head -2

# تبديل المزوّد إلى PostgreSQL
sed -i 's/provider = "sqlite"/provider = "postgresql"/' prisma/schema.prisma

echo "Provider after:"
grep "provider" prisma/schema.prisma | head -2

# التأكد من وجود DATABASE_URL
if [ -z "$DATABASE_URL" ]; then
  echo "ERROR: DATABASE_URL environment variable is not set"
  echo "Please add your Vercel Postgres connection string as DATABASE_URL"
  exit 1
fi

echo "=== Generating Prisma Client ==="
bunx prisma generate

echo "=== Pushing schema to Postgres ==="
bunx prisma db push

echo "=== Building Next.js ==="
bunx next build

echo "=== Build complete ==="
