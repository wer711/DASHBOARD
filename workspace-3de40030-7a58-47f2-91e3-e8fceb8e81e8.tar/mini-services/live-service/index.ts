/**
 * live-service — WebSocket relay for the Sada Al-Aqar analytics dashboard.
 *
 * Responsibilities:
 *  - Accept HTTP POST /internal/broadcast from the Next.js /api/track route
 *    and fan-out the payload to every connected dashboard client as
 *    `analytics:event`.
 *  - Keep an in-memory ring buffer of the last 100 events so newly
 *    connected dashboard clients immediately receive recent history
 *    via `analytics:history`.
 *  - Expose /internal/stats + /health for monitoring.
 *
 * The socket.io path MUST stay `/` so the Caddy gateway can forward
 * browser connections (`io("/?XTransformPort=3003")`) to this service.
 *
 * IMPORTANT: when socket.io is configured with `path: '/'`, engine.io's
 * path-matcher (`path === req.url.slice(0, path.length)`) matches every
 * URL (because every URL starts with `/`). That would cause engine.io to
 * intercept our custom HTTP routes too and reply with
 * `{"code":0,"message":"Transport unknown"}`. To work around that we let
 * socket.io attach normally, then pop its wrapped `request` listener and
 * install our own dispatcher that handles our HTTP routes first and only
 * delegates to the wrapped listener for everything else (i.e. real
 * socket.io connections).
 */

import { createServer, IncomingMessage, ServerResponse } from 'http'
import { Server, Socket } from 'socket.io'

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

/** A pageview event broadcast by the Next.js /api/track route. */
interface PageviewEvent {
  type: 'pageview'
  websiteId: string
  sessionId: string
  visitorId: string
  path: string
  title: string | null
  country: string | null
  countryCode: string | null
  city: string | null
  device: string | null
  browser: string | null
  os: string | null
  referrerDomain: string | null
  utmSource: string | null
  utmCampaign: string | null
  timestamp: string
}

/** A custom analytics event (signup, generate, note, …). */
interface CustomEvent {
  type: 'event'
  websiteId: string
  sessionId: string
  visitorId: string
  name: string
  category: string | null
  label: string | null
  country: string | null
  countryCode: string | null
  city: string | null
  device: string | null
  browser: string | null
  timestamp: string
}

/** A heartbeat ping from a tracked session. */
interface HeartbeatEvent {
  type: 'heartbeat'
  websiteId: string
  sessionId: string
  visitorId: string
  timestamp: string
}

/** A session-leave event. */
interface LeaveEvent {
  type: 'leave'
  websiteId: string
  sessionId: string
  visitorId: string
  timestamp: string
}

type AnalyticsEvent =
  | PageviewEvent
  | CustomEvent
  | HeartbeatEvent
  | LeaveEvent

interface StatsResponse {
  connectedClients: number
  totalBroadcasts: number
  startedAt: string
}

interface HealthResponse {
  ok: boolean
  uptime: number
}

interface WelcomePayload {
  message: string
  time: string
}

interface PongPayload {
  time: string
}

// ---------------------------------------------------------------------------
// State
// ---------------------------------------------------------------------------

const PORT = 3003
const HISTORY_LIMIT = 100
const MAX_BODY_BYTES = 1_000_000

const startedAt = new Date()
let connectedClients = 0
let totalBroadcasts = 0

/** Ring buffer of recent analytics events (newest first). */
const eventHistory: AnalyticsEvent[] = []

function pushHistory(event: AnalyticsEvent): void {
  eventHistory.unshift(event)
  if (eventHistory.length > HISTORY_LIMIT) {
    eventHistory.length = HISTORY_LIMIT
  }
}

function uptimeSeconds(): number {
  return Math.floor((Date.now() - startedAt.getTime()) / 1000)
}

// ---------------------------------------------------------------------------
// HTTP route helpers
// ---------------------------------------------------------------------------

function sendJson(res: ServerResponse, status: number, body: unknown): void {
  const payload = JSON.stringify(body)
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type',
  })
  res.end(payload)
}

function readBody(
  req: IncomingMessage,
  onDone: (raw: string, err: string | null) => void
): void {
  let raw = ''
  req.on('data', (chunk: Buffer) => {
    raw += chunk.toString()
    if (raw.length > MAX_BODY_BYTES) {
      req.destroy()
      onDone('', 'payload too large')
    }
  })
  req.on('error', (err: Error) => onDone('', err.message))
  req.on('end', () => onDone(raw, null))
}

/**
 * Dispatch a single HTTP request. Returns `true` if the request was for one
 * of our routes (and a response has been sent). Returns `false` otherwise,
 * meaning the caller should let socket.io's wrapped listener handle it.
 */
function handleHttpRequest(
  req: IncomingMessage,
  res: ServerResponse
): boolean {
  const url = req.url ?? ''
  const method = req.method ?? ''

  const isBroadcast = url.startsWith('/internal/broadcast')
  const isStats = url.startsWith('/internal/stats')
  const isHealth = url.startsWith('/health')

  const isMyRoute = isBroadcast || isStats || isHealth

  // Handle CORS preflight for our routes ourselves; let socket.io handle
  // preflight for its own polling endpoint.
  if (method === 'OPTIONS' && isMyRoute) {
    sendJson(res, 204, {})
    return true
  }

  if (!isMyRoute) return false

  // POST /internal/broadcast — called by /api/track
  if (method === 'POST' && isBroadcast) {
    readBody(req, (raw, err) => {
      if (err) {
        console.error('[broadcast] read error:', err)
        sendJson(res, 400, { ok: false, error: err })
        return
      }
      let payload: AnalyticsEvent
      try {
        payload = JSON.parse(raw) as AnalyticsEvent
      } catch (parseErr) {
        const msg =
          parseErr instanceof Error ? parseErr.message : String(parseErr)
        console.error('[broadcast] invalid JSON:', msg)
        sendJson(res, 400, { ok: false, error: 'invalid json' })
        return
      }
      if (!payload || typeof payload !== 'object' || !('type' in payload)) {
        console.error('[broadcast] missing type field')
        sendJson(res, 400, { ok: false, error: 'missing type' })
        return
      }

      // Fan-out to every connected dashboard client.
      io.emit('analytics:event', payload)
      pushHistory(payload)
      totalBroadcasts += 1

      console.log(
        `[broadcast] type=${payload.type} clients=${connectedClients} total=${totalBroadcasts}`
      )

      sendJson(res, 200, { ok: true })
    })
    return true
  }

  // GET /internal/stats
  if (method === 'GET' && isStats) {
    const body: StatsResponse = {
      connectedClients,
      totalBroadcasts,
      startedAt: startedAt.toISOString(),
    }
    sendJson(res, 200, body)
    return true
  }

  // GET /health
  if (method === 'GET' && isHealth) {
    const body: HealthResponse = { ok: true, uptime: uptimeSeconds() }
    sendJson(res, 200, body)
    return true
  }

  // Wrong method for one of our routes.
  sendJson(res, 405, { ok: false, error: 'method not allowed' })
  return true
}

// ---------------------------------------------------------------------------
// HTTP server
// ---------------------------------------------------------------------------

const httpServer = createServer()

// ---------------------------------------------------------------------------
// socket.io server
// ---------------------------------------------------------------------------

const io = new Server(httpServer, {
  // DO NOT change the path — Caddy uses it to forward browser connections
  // coming in as `io("/?XTransformPort=3003")`.
  path: '/',
  cors: {
    origin: '*',
    methods: ['GET', 'POST'],
  },
  pingTimeout: 60000,
  pingInterval: 25000,
})

// socket.io + engine.io have now wrapped the http server's `request`
// listeners. Because we use path `/`, that wrapped listener would
// intercept EVERY HTTP request (including /health, /internal/stats and
// /internal/broadcast) and respond with `Transport unknown`. Pop the
// wrapped listener(s) and install our own dispatcher that handles our
// HTTP routes first and otherwise delegates to the wrapped listener.
const wrappedRequestListeners = httpServer.listeners('request').slice(0)
httpServer.removeAllListeners('request')
httpServer.on('request', (req, res) => {
  if (handleHttpRequest(req, res)) return
  for (const fn of wrappedRequestListeners) {
    fn.call(httpServer, req, res)
  }
})

io.on('connection', (socket: Socket) => {
  connectedClients += 1
  console.log(
    `[socket] client connected id=${socket.id} clients=${connectedClients}`
  )

  const welcome: WelcomePayload = {
    message: 'connected to live analytics',
    time: new Date().toISOString(),
  }
  socket.emit('welcome', welcome)

  // Send recent history to the new client so the dashboard isn't blank
  // on first paint.
  socket.emit('analytics:history', eventHistory.slice(0, HISTORY_LIMIT))

  socket.on('ping', () => {
    const pong: PongPayload = { time: new Date().toISOString() }
    socket.emit('pong', pong)
  })

  socket.on('error', (err: Error) => {
    console.error(`[socket] error id=${socket.id}:`, err.message)
  })

  socket.on('disconnect', (reason: string) => {
    connectedClients = Math.max(0, connectedClients - 1)
    console.log(
      `[socket] client disconnected id=${socket.id} reason=${reason} clients=${connectedClients}`
    )
  })
})

// ---------------------------------------------------------------------------
// Graceful shutdown
// ---------------------------------------------------------------------------

function shutdown(signal: string): void {
  console.log(`[shutdown] received ${signal}, closing live-service...`)
  io.close(() => {
    httpServer.close(() => {
      console.log('[shutdown] http server closed')
      process.exit(0)
    })
  })
  // Hard-exit fallback in case any socket refuses to drain.
  setTimeout(() => {
    console.error('[shutdown] force-exiting after timeout')
    process.exit(1)
  }, 5000).unref()
}

process.on('SIGTERM', () => shutdown('SIGTERM'))
process.on('SIGINT', () => shutdown('SIGINT'))
process.on('uncaughtException', (err: Error) => {
  console.error('[fatal] uncaughtException:', err)
})
process.on('unhandledRejection', (reason: unknown) => {
  console.error('[fatal] unhandledRejection:', reason)
})

// ---------------------------------------------------------------------------
// Boot
// ---------------------------------------------------------------------------

httpServer.listen(PORT, () => {
  console.log(
    `[live-service] running on port ${PORT} (socket.io path=/, http endpoints: /internal/broadcast, /internal/stats, /health)`
  )
})
